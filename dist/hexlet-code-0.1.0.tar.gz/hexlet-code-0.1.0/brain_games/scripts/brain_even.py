#!/usr/bin/env/python

from brain_games.gamescode.even_game import is_even
from brain_games.logic import logic


def main():
    logic(is_even)


if __name__ == '__main__':
    main()
